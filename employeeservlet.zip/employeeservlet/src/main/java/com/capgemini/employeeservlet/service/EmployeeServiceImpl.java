package com.capgemini.employeeservlet.service;

import java.util.List;

import com.capgemini.employeeservlet.bean.EmployeeInfoBean;
import com.capgemini.employeeservlet.dao.EmployeeDAO;
import com.capgemini.employeeservlet.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO empdao=new EmployeeDAOImpl();

	public EmployeeInfoBean getEmployeeByid(int Id) {
		// TODO Auto-generated method stub
		return empdao.getEmployeeByid(Id);
	}

	public boolean addEmployee(EmployeeInfoBean bean) {
		// TODO Auto-generated method stub
		return empdao.addEmployee(bean);
	}

	public boolean updateEmployee(EmployeeInfoBean bean) {
		// TODO Auto-generated method stub
		return empdao.updateEmployee(bean);
	}

	public boolean deleteEmployee(int Id) {
		// TODO Auto-generated method stub
		return empdao.deleteEmployee(Id);
	}

	public List<EmployeeInfoBean> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public EmployeeInfoBean authenticate(int empId, String password) {
		// TODO Auto-generated method stub
		return empdao.authenticate(empId, password);
	}

}
