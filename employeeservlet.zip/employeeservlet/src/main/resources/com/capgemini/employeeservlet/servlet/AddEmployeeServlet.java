package com.capgemini.servletemployee.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.servletemployee.dto.EmployeeBean;
import com.capgemini.servletemployee.service.EmployeeService;
import com.capgemini.servletemployee.service.EmployeeServiceImpl;
@WebServlet("./addemp")

public class AddEmployeeServlet extends HttpServlet{
	EmployeeService empService = new EmployeeServiceImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String empId1 = req.getParameter("empId");
		int empId = Integer.parseInt(empId1);
		String empName  = req.getParameter("empName");
		String ageVal = req.getParameter("age");
		int age  = Integer.parseInt(ageVal);
		String  salary1 = req.getParameter("salary");
        double salary = Double.parseDouble(salary1);
        String designation  = req.getParameter("designation");
        String password = req.getParameter("password");
        
        EmployeeBean employeeBean = new EmployeeBean();
        employeeBean.setEmpId(empId);
        employeeBean.setEmpName(empName);
        employeeBean.setAge(age);
        employeeBean.setSalary(salary);
        employeeBean.setDesignation(designation);
        employeeBean.setPassword(password);
		resp.setContentType("test/html");
		
		boolean added = empService.addEmployee(employeeBean);
		
		PrintWriter out = resp.getWriter();
		
		out.println("<html>");
		out.println("<body>");
		if(added) {
			out.print("<h2 style='color: yellow'>Employee Added Succesfully</h2>");
			
		}else {
			out.print("<h2 style='color: red'>Unable to add succefully!!</h2>");

		}
		out.println("EmployeeId" +empId);
		out.println("<br>EmployyeName= "+empName);
		out.println("<br>Employee age : " +age);
		out.println("<br>Employee salary : " +salary);
		out.println("<br>designation : " +designation);
		out.println("<br>Employee password : " +password);
		out.println("</body>");
		out.println("</html>");
		RequestDispatcher dispatcher =req.getRequestDispatcher("./homepage.html");
		dispatcher.include(req, resp);
		
		}
	

}
